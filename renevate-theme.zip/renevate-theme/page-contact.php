
<?php
/* Template Name: Contact Page */
get_header();
?>
<section class="panel">
  <h2>Contact Us</h2>
  <p class="lead">Get in touch for partnership, project enquiries or donations.</p>
  <p>Email: rawatashok88@gmail.com<br>Phone: +91 96307 59699</p>
</section>
<?php get_footer(); ?>
